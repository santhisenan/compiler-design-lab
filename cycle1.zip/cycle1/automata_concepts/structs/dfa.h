#ifndef _DFA
#define _DFA

#include <vector>
#include <unordered_set>
using namespace std;

struct dfa
{
    int states, alphabets;
    vector<vector<unordered_set<int>>> table; // to store the transition table
};

#endif